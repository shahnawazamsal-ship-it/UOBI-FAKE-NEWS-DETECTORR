
import React from 'react';

interface LayoutProps {
  children: React.ReactNode;
}

const Layout: React.FC<LayoutProps> = ({ children }) => {
  return (
    <div className="min-h-screen bg-slate-50 flex flex-col">
      <header className="bg-white border-b border-slate-200 sticky top-0 z-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex justify-between h-16 items-center">
            <div className="flex items-center space-x-2">
              <div className="bg-indigo-600 p-2 rounded-lg">
                <svg className="w-6 h-6 text-white" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 12l2 2 4-4m5.618-4.016A11.955 11.955 0 0112 2.944a11.955 11.955 0 01-8.618 3.04A12.02 12.02 0 003 9c0 5.591 3.824 10.29 9 11.622 5.176-1.332 9-6.03 9-11.622 0-1.042-.133-2.052-.382-3.016z" />
                </svg>
              </div>
              <h1 className="text-xl font-bold text-slate-900 tracking-tight">
                UOBI <span className="text-indigo-600">FAKE NEWS DETECTOR</span>
              </h1>
            </div>
            <nav className="hidden md:flex space-x-8">
              <span className="text-sm font-medium text-slate-500 hover:text-indigo-600 cursor-pointer transition">Dashboard</span>
              <span className="text-sm font-medium text-slate-500 hover:text-indigo-600 cursor-pointer transition">Methodology</span>
              <span className="text-sm font-medium text-slate-500 hover:text-indigo-600 cursor-pointer transition">API</span>
            </nav>
          </div>
        </div>
      </header>

      <main className="flex-grow">
        {children}
      </main>

      <footer className="bg-white border-t border-slate-200 py-8">
        <div className="max-w-7xl mx-auto px-4 text-center">
          <p className="text-slate-400 text-sm">
            &copy; {new Date().getFullYear()} UOBI Intelligence. Powered by Advanced Machine Learning Paradigms.
          </p>
        </div>
      </footer>
    </div>
  );
};

export default Layout;
