
import React from 'react';
import { DetectionResult, ModelType } from '../types';
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, Cell } from 'recharts';

interface ResultDisplayProps {
  result: DetectionResult;
}

const ResultDisplay: React.FC<ResultDisplayProps> = ({ result }) => {
  const chartData = result.predictions.map(p => ({
    name: p.modelType,
    confidence: p.confidence,
    label: p.label,
    color: p.label === 'Real' ? '#10b981' : '#ef4444'
  }));

  const getConsensusColor = () => {
    if (result.overallConsensus === 'Real') return 'bg-emerald-50 border-emerald-200 text-emerald-800';
    if (result.overallConsensus === 'Fake') return 'bg-rose-50 border-rose-200 text-rose-800';
    return 'bg-amber-50 border-amber-200 text-amber-800';
  };

  const getBadgeColor = (label: string) => {
    return label === 'Real' 
      ? 'bg-emerald-100 text-emerald-700 border-emerald-200' 
      : 'bg-rose-100 text-rose-700 border-rose-200';
  };

  return (
    <div className="space-y-8 animate-in fade-in duration-700">
      {/* Overview Card */}
      <div className={`p-6 rounded-2xl border ${getConsensusColor()} shadow-sm`}>
        <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
          <div>
            <h2 className="text-2xl font-bold mb-1">Detection Result: {result.overallConsensus}</h2>
            <p className="opacity-90 leading-relaxed">
              {result.analysisSummary}
            </p>
          </div>
          <div className="flex-shrink-0">
            <div className={`inline-flex items-center px-6 py-3 rounded-full text-lg font-bold border-2 ${result.overallConsensus === 'Real' ? 'border-emerald-500 text-emerald-600' : 'border-rose-500 text-rose-600'}`}>
              {result.overallConsensus.toUpperCase()}
            </div>
          </div>
        </div>
      </div>

      {/* Grid of Models */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
        {/* Chart Card */}
        <div className="bg-white p-6 rounded-2xl border border-slate-200 shadow-sm">
          <h3 className="text-lg font-semibold text-slate-900 mb-6">Model Confidence Comparison</h3>
          <div className="h-80 w-full">
            <ResponsiveContainer width="100%" height="100%">
              <BarChart data={chartData} margin={{ top: 5, right: 30, left: 0, bottom: 5 }}>
                <CartesianGrid strokeDasharray="3 3" vertical={false} />
                <XAxis dataKey="name" axisLine={false} tickLine={false} tick={{ fontSize: 11 }} />
                <YAxis domain={[0, 100]} axisLine={false} tickLine={false} />
                <Tooltip 
                  cursor={{ fill: 'rgba(0,0,0,0.05)' }}
                  content={({ active, payload }) => {
                    if (active && payload && payload.length) {
                      const data = payload[0].payload;
                      return (
                        <div className="bg-white border border-slate-200 p-3 rounded-lg shadow-xl">
                          <p className="font-bold text-slate-800">{data.name}</p>
                          <p className="text-sm font-medium" style={{ color: data.color }}>
                            {data.label} ({data.confidence}%)
                          </p>
                        </div>
                      );
                    }
                    return null;
                  }}
                />
                <Bar dataKey="confidence" radius={[6, 6, 0, 0]}>
                  {chartData.map((entry, index) => (
                    <Cell key={`cell-${index}`} fill={entry.color} />
                  ))}
                </Bar>
              </BarChart>
            </ResponsiveContainer>
          </div>
        </div>

        {/* Detailed Explanation List */}
        <div className="space-y-4">
          {result.predictions.map((p, idx) => (
            <div key={idx} className="bg-white p-5 rounded-xl border border-slate-200 shadow-sm hover:shadow-md transition-shadow">
              <div className="flex justify-between items-start mb-3">
                <div>
                  <h4 className="font-bold text-slate-900">{p.modelType}</h4>
                  <p className="text-xs text-slate-400 mono">Classifier Module #{idx + 1}</p>
                </div>
                <span className={`px-3 py-1 rounded-full text-xs font-bold border ${getBadgeColor(p.label)}`}>
                  {p.label} ({p.confidence}%)
                </span>
              </div>
              <p className="text-sm text-slate-600 leading-relaxed">
                {p.explanation}
              </p>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
};

export default ResultDisplay;
