
import React, { useState } from 'react';
import Layout from './components/Layout';
import { DetectionResult } from './types';
import { analyzeNewsVeracity } from './services/geminiService';
import ResultDisplay from './components/ResultDisplay';

const App: React.FC = () => {
  const [inputText, setInputText] = useState('');
  const [isAnalyzing, setIsAnalyzing] = useState(false);
  const [result, setResult] = useState<DetectionResult | null>(null);
  const [error, setError] = useState<string | null>(null);

  const handleAnalyze = async () => {
    if (!inputText.trim() || inputText.length < 50) {
      setError("Please enter at least 50 characters of news text for accurate analysis.");
      return;
    }

    setIsAnalyzing(true);
    setError(null);
    setResult(null);

    try {
      const data = await analyzeNewsVeracity(inputText);
      setResult(data);
    } catch (err: any) {
      setError(err.message || "An unexpected error occurred.");
    } finally {
      setIsAnalyzing(false);
    }
  };

  const resetForm = () => {
    setInputText('');
    setResult(null);
    setError(null);
  };

  return (
    <Layout>
      <div className="max-w-6xl mx-auto px-4 py-12">
        {/* Hero Section */}
        <div className="text-center mb-12">
          <h2 className="text-4xl font-extrabold text-slate-900 mb-4 tracking-tight sm:text-5xl">
            Detect Misinformation with <br/>
            <span className="text-transparent bg-clip-text bg-gradient-to-r from-indigo-600 to-violet-600">
              UOBI Predictive Intelligence
            </span>
          </h2>
          <p className="text-lg text-slate-600 max-w-2xl mx-auto">
            Input news headlines or articles to verify authenticity using our dual-model 
            machine learning verification suite.
          </p>
        </div>

        {/* Search / Input Box */}
        <div className="max-w-4xl mx-auto mb-16">
          <div className="bg-white rounded-2xl shadow-xl shadow-indigo-100 border border-slate-200 p-2">
            <div className="relative">
              <textarea
                className="w-full min-h-[180px] p-6 text-slate-800 text-lg bg-transparent focus:outline-none resize-none placeholder-slate-300"
                placeholder="Paste news content or headline here for real-time verification..."
                value={inputText}
                onChange={(e) => setInputText(e.target.value)}
                disabled={isAnalyzing}
              />
              <div className="flex items-center justify-between px-6 py-4 border-t border-slate-100">
                <div className="flex space-x-2">
                   <div className="flex items-center space-x-1 px-2 py-1 rounded bg-slate-50 text-[10px] text-slate-400 font-bold uppercase tracking-wider border border-slate-200">
                    <span className="w-1.5 h-1.5 rounded-full bg-emerald-400"></span>
                    <span>Systems Ready</span>
                  </div>
                  <div className="flex items-center space-x-1 px-2 py-1 rounded bg-slate-50 text-[10px] text-slate-400 font-bold uppercase tracking-wider border border-slate-200">
                    <span className="w-1.5 h-1.5 rounded-full bg-indigo-400"></span>
                    <span>Ensemble Active</span>
                  </div>
                </div>
                <div className="flex space-x-3">
                  {result && (
                    <button
                      onClick={resetForm}
                      className="px-6 py-2 text-slate-500 hover:text-slate-800 font-medium transition"
                    >
                      Clear
                    </button>
                  )}
                  <button
                    onClick={handleAnalyze}
                    disabled={isAnalyzing || !inputText.trim()}
                    className={`px-8 py-3 rounded-xl font-bold text-white transition-all shadow-lg flex items-center space-x-2 ${
                      isAnalyzing || !inputText.trim()
                        ? 'bg-slate-300 cursor-not-allowed'
                        : 'bg-indigo-600 hover:bg-indigo-700 hover:scale-[1.02] shadow-indigo-200'
                    }`}
                  >
                    {isAnalyzing ? (
                      <>
                        <svg className="animate-spin -ml-1 mr-3 h-5 w-5 text-white" fill="none" viewBox="0 0 24 24">
                          <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4"></circle>
                          <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"></path>
                        </svg>
                        <span>Analyzing Features...</span>
                      </>
                    ) : (
                      <>
                        <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                          <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M13 10V3L4 14h7v7l9-11h-7z" />
                        </svg>
                        <span>Analyze Veracity</span>
                      </>
                    )}
                  </button>
                </div>
              </div>
            </div>
          </div>
          {error && (
            <div className="mt-4 p-4 bg-rose-50 border border-rose-100 rounded-xl text-rose-600 text-sm flex items-center space-x-3">
              <svg className="w-5 h-5 flex-shrink-0" fill="currentColor" viewBox="0 0 20 20">
                <path fillRule="evenodd" d="M18 10a8 8 0 11-16 0 8 8 0 0116 0zm-7 4a1 1 0 11-2 0 1 1 0 012 0zm-1-9a1 1 0 00-1 1v4a1 1 0 102 0V6a1 1 0 00-1-1z" clipRule="evenodd" />
              </svg>
              <span>{error}</span>
            </div>
          )}
        </div>

        {/* Prediction Results */}
        {result && <ResultDisplay result={result} />}

        {/* Model Explanation Section */}
        {!result && !isAnalyzing && (
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mt-12 opacity-60 max-w-2xl mx-auto">
            {[
              { title: 'Logistic Regression', desc: 'Analyzes linear probability of word distributions based on frequency features.' },
              { title: 'Random Forest', desc: 'An ensemble of decision trees classifying linguistic features and structural metadata.' }
            ].map((m, i) => (
              <div key={i} className="bg-white border border-slate-200 p-5 rounded-xl">
                <h4 className="font-bold text-slate-800 mb-1">{m.title}</h4>
                <p className="text-xs text-slate-500 leading-relaxed">{m.desc}</p>
              </div>
            ))}
          </div>
        )}
      </div>
    </Layout>
  );
};

export default App;
