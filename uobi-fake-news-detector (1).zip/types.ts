
export enum ModelType {
  LOGISTIC_REGRESSION = 'Logistic Regression',
  RANDOM_FOREST = 'Random Forest'
}

export interface ModelPrediction {
  modelType: ModelType;
  confidence: number; // 0 to 100
  label: 'Real' | 'Fake';
  explanation: string;
}

export interface DetectionResult {
  text: string;
  predictions: ModelPrediction[];
  overallConsensus: 'Real' | 'Fake' | 'Inconclusive';
  analysisSummary: string;
  sourceCheckHint?: string;
}

export interface GeminiResponse {
  predictions: {
    modelType: string;
    confidence: number;
    label: string;
    explanation: string;
  }[];
  overallConsensus: string;
  analysisSummary: string;
}
