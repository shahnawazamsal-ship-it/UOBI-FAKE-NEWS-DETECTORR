
import { GoogleGenAI, Type } from "@google/genai";
import { DetectionResult, ModelType } from "../types";

const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });

const DETECTION_SCHEMA = {
  type: Type.OBJECT,
  properties: {
    predictions: {
      type: Type.ARRAY,
      items: {
        type: Type.OBJECT,
        properties: {
          modelType: { type: Type.STRING },
          confidence: { type: Type.NUMBER },
          label: { type: Type.STRING },
          explanation: { type: Type.STRING },
        },
        required: ["modelType", "confidence", "label", "explanation"],
      },
    },
    overallConsensus: { type: Type.STRING },
    analysisSummary: { type: Type.STRING },
  },
  required: ["predictions", "overallConsensus", "analysisSummary"],
};

export const analyzeNewsVeracity = async (text: string): Promise<DetectionResult> => {
  const prompt = `
    As a world-class fact-checking AI, analyze the following news text for veracity.
    You must simulate the output of two distinct machine learning classification paradigms:
    1. Logistic Regression (Focus on linear statistical word patterns, term frequencies, and high-weight coefficients)
    2. Random Forest (Focus on decision-tree based feature ensembles like metadata, structural punctuation, and keyword clusters)

    Input News Text:
    """
    ${text}
    """

    Return the analysis in JSON format. Each model must have a 'label' (Real or Fake) and a 'confidence' score (0-100).
    Provide a brief explanation for why each model reached its conclusion based on its specific technical characteristics.
  `;

  try {
    const response = await ai.models.generateContent({
      model: "gemini-3-flash-preview",
      contents: prompt,
      config: {
        responseMimeType: "application/json",
        responseSchema: DETECTION_SCHEMA,
      },
    });

    const data = JSON.parse(response.text.trim());
    
    // Map internal strings to Typed Enums
    const predictions = data.predictions.map((p: any) => ({
      ...p,
      modelType: Object.values(ModelType).find(v => v.toLowerCase().includes(p.modelType.toLowerCase())) || p.modelType
    }));

    return {
      text,
      predictions,
      overallConsensus: data.overallConsensus as any,
      analysisSummary: data.analysisSummary,
    };
  } catch (error) {
    console.error("Gemini Analysis Error:", error);
    throw new Error("Failed to analyze the news veracity. Please check your network or try a shorter text.");
  }
};
